package com.example.presell.fragments;

import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager.widget.ViewPager;

import com.example.presell.R;
import com.example.presell.SnapScrollListener;
import com.example.presell.adapters.PostRecyclerAdapter;
import com.example.presell.adapters.CategoryRecyclerViewAdapter;
import com.example.presell.models.GenAppInfo;
import com.example.presell.models.Post;

import java.util.ArrayList;

public class HomeFragment extends Fragment {
    private static final int MIN_TEXT_SIZE = 14;
    private static final int MAX_TEXT_SIZE = 20;

    private static final int MAX_ADDED_TEXT_SIZE = 6;

    private ArrayList<String> categoriesList;
    private ViewPager mViewPager;
    private PostRecyclerAdapter mAdapter;
    private int firstVisibleCategoryIndex;
    private String category;
    private GenAppInfo mInfo;

    private int selectedCategory;
    private RecyclerView mRecyclerView;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setupActionBar();
        categoriesList = instantiateCategories(new ArrayList<String>());
        mInfo = new GenAppInfo(getContext().getApplicationContext());

        category = mInfo.getSelectedCategory();
    }

    public static ArrayList<String> instantiateCategories(ArrayList<String> categoriesList){
        categoriesList.add("T-Shirts");
        categoriesList.add("Mugs");
        categoriesList.add("Coasters");
        categoriesList.add("Plates");
        categoriesList.add("Stickers");
        categoriesList.add("Airpods Skins");

        return categoriesList;
    }

    private void setupCategoriesPager(){
        RecyclerView recyclerView = getActivity().findViewById(R.id.rvAnimals);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext(), LinearLayoutManager.HORIZONTAL, false){
            @Override
            public boolean checkLayoutParams(RecyclerView.LayoutParams lp) {
                // force height of viewHolder here, this will override layout_height from xml
                lp.width = getWidth() / 3;
                return true;
            }
        });
        recyclerView.addOnScrollListener(new SnapScrollListener(categoriesList));
        CategoryRecyclerViewAdapter adapter = new CategoryRecyclerViewAdapter(getContext(), categoriesList);
        recyclerView.setAdapter(adapter);
    }

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        setHasOptionsMenu(true);

        View root = inflater.inflate(R.layout.fragment_home, container, false);

        return root;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        Log.d("HomeFragment", "onViewCreated() " + category);
        setupCategoriesPager();

        mRecyclerView = view.findViewById(R.id.feed_recyclerview);
        LinearLayoutManager mLinLayoutManager = new LinearLayoutManager(getContext());
        mRecyclerView.setLayoutManager(mLinLayoutManager);

        if(!category.equals("none")) {
            RecyclerView categoryRecyclerView = view.findViewById(R.id.rvAnimals);
            categoryRecyclerView.scrollToPosition(getCategoryPosition(category));
            mInfo.setSelectedCategory("none");
        }

        loadPosts();
    }

    private int getCategoryPosition(String category){
        for(int i = 0; i < categoriesList.size(); i++){
            if(categoriesList.get(i).equals(category)){
                if(i==0){
                    return categoriesList.size()-1;
                }
                return i-1;
            }
        }
        return 3;
    }

    @Override
    public void onCreateOptionsMenu(@NonNull Menu menu, @NonNull MenuInflater inflater) {
        Log.d("HomeFragment", "onCreateOptionsMenu()");
        menu.clear();
        getActivity().getMenuInflater().inflate(R.menu.home_menu, menu);
        super.onCreateOptionsMenu(menu, inflater);
    }

    private void setupActionBar(){
        Log.d("HomeFragment", "setupActionBar()");
        ActionBar actionBar;
        if((actionBar = ((AppCompatActivity)getActivity()).getSupportActionBar())!=null) {
            Log.d("HomeFragment", "setupActionBar() inside statement");

            actionBar.setTitle("PreSell");
            actionBar.setDisplayHomeAsUpEnabled(true);
            actionBar.setBackgroundDrawable(new ColorDrawable((ContextCompat.getColor(getContext().getApplicationContext(), R.color.darkBackground))));
        }
    }

    private void loadPosts(){
        ArrayList<Post> posts = new ArrayList<>();

        Post post = emptyPost();
        post.setId(-1);
        posts.add(post);
        posts.add(post);
        posts.add(post);

        mRecyclerView.setAdapter(new PostRecyclerAdapter(getContext(), posts));
    }


    /**
     * Default post value when there's nothing to show in feed
     */
    private Post emptyPost(){
        Post post = new Post();
        post.setTitle("Empty Post");
        post.setName("Admin");
        return post;
    }
}
