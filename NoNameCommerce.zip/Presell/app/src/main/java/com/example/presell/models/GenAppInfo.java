package com.example.presell.models;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

public class GenAppInfo {
    private SharedPreferences mInfo;

    public GenAppInfo(Context applicationContext){
        mInfo = PreferenceManager.getDefaultSharedPreferences(applicationContext);
    }

    public String getSelectedCategory(){
        return mInfo.getString("selected category", "none");
    }

    public void setSelectedCategory(String category){
        mInfo.edit().putString("selected category", category).apply();
    }


}
