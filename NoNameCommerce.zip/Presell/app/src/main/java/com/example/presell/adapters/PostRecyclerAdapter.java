package com.example.presell.adapters;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.example.presell.R;
import com.example.presell.activities.BuyActivity;
import com.example.presell.fragments.PostFragment;
import com.example.presell.models.Post;

import java.util.List;

public class PostRecyclerAdapter extends RecyclerView.Adapter<PostRecyclerAdapter.PostViewHolder> {
    private List<Post> posts;
    private Context context;

    public static class PostViewHolder extends RecyclerView.ViewHolder {
        // Card fields
        private TextView title;
        private TextView username;
        private ImageView mainImage;
        private ImageView heartIcon;
        private Context context;

        public PostViewHolder(View v, Context context) {
            super(v);
            this.context = context;
            title = (TextView) v.findViewById(R.id.post_title_text);
            username = (TextView) v.findViewById(R.id.user_text);
            mainImage = (ImageView)v.findViewById(R.id.postImageButton);
            heartIcon = (ImageView) v.findViewById(R.id.heart_icon);

            setupOnClickListeners();
        }

        private void setupOnClickListeners(){
            title.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    context.startActivity(new Intent(context, BuyActivity.class));
                }
            });
            username.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    context.startActivity(new Intent(context, BuyActivity.class));
                }
            });
            mainImage.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    context.startActivity(new Intent(context, BuyActivity.class));
                }
            });
        }
    }

    public PostRecyclerAdapter(Context context, List<Post> posts) {
        this.posts = posts;
        this.context = context;
    }

    public void addPost(Post post) {
        // Add the event at the beginning of the list
        posts.add(0, post);
        // Notify the insertion so the view can be refreshed
        notifyItemInserted(0);
    }

    @Override
    public int getItemCount() {
        return posts.size();
    }

    @Override
    public PostViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        View v = LayoutInflater.from(viewGroup.getContext())
                .inflate(R.layout.feed_post, viewGroup, false);

        return new PostViewHolder(v, context);
    }

    @Override
    public void onBindViewHolder(final PostViewHolder viewHolder, int i) {
        Post post = posts.get(i);

        viewHolder.title.setText(post.getTitle());
        viewHolder.username.setText(post.getName());
        viewHolder.heartIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(viewHolder.heartIcon.getContentDescription().equals("filled in")){
                    viewHolder.heartIcon.setImageResource(R.drawable.ic_favorite_border_24px);
                    viewHolder.heartIcon.setColorFilter(ContextCompat.getColor(context, R.color.lighterRed), android.graphics.PorterDuff.Mode.SRC_IN);
                    viewHolder.heartIcon.setContentDescription("outline");
                }
                else {
                    viewHolder.heartIcon.setImageResource(R.drawable.ic_favorite_24px);
                    viewHolder.heartIcon.setColorFilter(ContextCompat.getColor(context, R.color.lighterRed), android.graphics.PorterDuff.Mode.SRC_IN);
                    viewHolder.heartIcon.setContentDescription("filled in");
                }
            }
        });
//        viewHolder.data.setText(event.getData());
    }
}