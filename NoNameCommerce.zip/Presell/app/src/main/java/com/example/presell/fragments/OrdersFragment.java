package com.example.presell.fragments;

import androidx.fragment.app.Fragment;

public class OrdersFragment extends Fragment {
}
