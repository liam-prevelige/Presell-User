package com.example.presell.activities;

import android.content.Context;
import android.os.Bundle;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;

import com.example.presell.R;
import com.example.presell.fragments.HomeFragment;
import com.example.presell.fragments.MyProfileFragment;
import com.example.presell.fragments.OrdersFragment;
import com.example.presell.fragments.SearchFragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.bottomnavigation.LabelVisibilityMode;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private BottomNavigationView bottomNavigationView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Log.d("TEST", "IS IT WORKING?");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new HomeFragment()).commit();

        Log.d("MainActivity", "not assigned yet");
        bottomNavigationView = (BottomNavigationView)findViewById(R.id.nav_view);
        Log.d("MainActivity", "now assigned");
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull String name, @NonNull Context context, @NonNull AttributeSet attrs) {
        View view = super.onCreateView(name, context, attrs);


//        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
//            @Override
//            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
//                Log.d("MainActivity", "onNavigationItemSelected()");
//                bottomNavigationView.setSelectedItemId(item.getItemId());
//                return true;
//            }
//        });
        return view;
    }

    public void onClickHome(MenuItem item) {
        Log.d("MainActivity", "onClickHome()");
        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new HomeFragment()).commit();
    }

    public void onClickSearch(MenuItem item) {
        Log.d("MainActivity", "onClickSearch()");

        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new SearchFragment()).commit();
    }

    public void onClickOrders(MenuItem item) {
        Log.d("MainActivity", "onClickOrders()");

        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new OrdersFragment()).commit();
    }

    public void onClickMe(MenuItem item) {
        Log.d("MainActivity", "onClickMe()");

        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new MyProfileFragment()).commit();
    }
}
